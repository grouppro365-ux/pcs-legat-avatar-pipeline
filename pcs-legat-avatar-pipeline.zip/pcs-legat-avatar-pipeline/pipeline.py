from __future__ import annotations

import json
import os
import shutil
import subprocess
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable


class PipelineError(RuntimeError):
    pass


def run(cmd: list[str] | str, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess:
    print(f"$ {cmd if isinstance(cmd, str) else ' '.join(cmd)}")
    return subprocess.run(cmd, cwd=cwd, shell=isinstance(cmd, str), text=True, check=check)


def capture(cmd: list[str]) -> str:
    return subprocess.check_output(cmd, text=True).strip()


def newest_mp4(folder: Path) -> Path:
    candidates = list(folder.rglob('*.mp4'))
    if not candidates:
        raise PipelineError(f"No MP4 found under {folder}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def ffprobe(path: Path) -> dict:
    raw = capture([
        'ffprobe', '-v', 'error', '-show_streams', '-show_format',
        '-of', 'json', str(path)
    ])
    return json.loads(raw)


def normalize_1080p(source: Path, target: Path, duration: float | None = None) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    vf = (
        "scale=1920:1080:force_original_aspect_ratio=decrease,"
        "pad=1920:1080:(ow-iw)/2:(oh-ih)/2:black,fps=30,format=yuv420p"
    )
    cmd = ['ffmpeg', '-y', '-i', str(source), '-vf', vf]
    if duration is not None:
        cmd += ['-t', f'{duration:.3f}']
    cmd += ['-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-c:a', 'aac', '-b:a', '192k', str(target)]
    run(cmd)


def trim_audio(source: Path, target: Path, seconds: float) -> None:
    run([
        'ffmpeg', '-y', '-i', str(source), '-t', str(seconds), '-ar', '16000',
        '-ac', '1', '-c:a', 'pcm_s16le', str(target)
    ])


def validate_gpu(min_vram_gb: float = 14.0) -> dict:
    if shutil.which('nvidia-smi') is None:
        raise PipelineError('Kaggle GPU is not enabled.')
    name = capture(['nvidia-smi', '--query-gpu=name', '--format=csv,noheader']).splitlines()[0]
    mem_mib = float(capture(['nvidia-smi', '--query-gpu=memory.total', '--format=csv,noheader,nounits']).splitlines()[0])
    info = {'name': name, 'memory_total_mib': mem_mib, 'memory_total_gb': round(mem_mib / 1024, 2)}
    print(json.dumps(info, ensure_ascii=False, indent=2))
    if mem_mib < min_vram_gb * 1024:
        raise PipelineError(f'GPU has only {mem_mib/1024:.1f} GB VRAM; EchoMimicV2 needs about 16 GB.')
    return info


def write_report(files: Iterable[Path], output: Path) -> dict:
    report = {}
    for path in files:
        if path.exists():
            report[path.name] = ffprobe(path)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return report
